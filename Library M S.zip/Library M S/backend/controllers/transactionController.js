const Transaction = require('../models/Transaction');
const Book = require('../models/Book');
const Membership = require('../models/Membership');
const mongoose = require('mongoose');


exports.issueBook = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const { membershipId, bookSerialNo, issueDate, returnDate, remarks } = req.body;

    
    const membership = await Membership.findOne({ membershipId }).session(session);
    if (!membership) {
      throw new Error('Membership not found');
    }

    if (membership.status !== 'ACTIVE') {
      throw new Error('Membership is not active');
    }

    if (membership.endDate && new Date(membership.endDate) < new Date()) {
      throw new Error('Membership has expired');
    }

   
    const activeTransactions = await Transaction.find({
      membership: membership._id,
      status: 'ACTIVE'
    }).session(session);

    for (const trans of activeTransactions) {
      trans.calculateFine();
      if (trans.fineCalculated > 0) {
        throw new Error('Member has overdue books. Please return them first.');
      }
    }

  
    const book = await Book.findOne({ serialNo: bookSerialNo }).session(session);
    if (!book) {
      throw new Error('Book not found');
    }

    if (book.status !== 'AVAILABLE') {
      throw new Error('Book is not available');
    }

    
    const existingIssue = await Transaction.findOne({
      membership: membership._id,
      book: book._id,
      status: 'ACTIVE'
    }).session(session);

    if (existingIssue) {
      throw new Error('Member already has this book issued');
    }

    
    const issueDateObj = issueDate ? new Date(issueDate) : new Date();
    let returnDateObj = returnDate ? new Date(returnDate) : 
      new Date(issueDateObj.getTime() + (15 * 24 * 60 * 60 * 1000));

   
    const daysDiff = Math.ceil((returnDateObj - issueDateObj) / (1000 * 60 * 60 * 24));
    if (daysDiff > 15) {
      throw new Error('Return date cannot be more than 15 days from issue date');
    }

    if (returnDateObj < issueDateObj) {
      throw new Error('Return date cannot be before issue date');
    }

    
    const transaction = new Transaction({
      membership: membership._id,
      book: book._id,
      transactionType: 'ISSUE',
      issueDate: issueDateObj,
      returnDate: returnDateObj,
      remarks,
      status: 'ACTIVE'
    });

    await transaction.save({ session });

   
    book.status = 'ISSUED';
    await book.save({ session });

    await session.commitTransaction();
    session.endSession();

  
    const populatedTransaction = await Transaction.findById(transaction._id)
      .populate('membership')
      .populate('book');

    res.json({
      success: true,
      message: 'Book issued successfully',
      transaction: populatedTransaction
    });
  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};


exports.returnBook = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const { membershipId, bookSerialNo, actualReturnDate, remarks } = req.body;

    const membership = await Membership.findOne({ membershipId }).session(session);
    if (!membership) {
      throw new Error('Membership not found');
    }

    const book = await Book.findOne({ serialNo: bookSerialNo }).session(session);
    if (!book) {
      throw new Error('Book not found');
    }

    const transaction = await Transaction.findOne({
      membership: membership._id,
      book: book._id,
      status: 'ACTIVE'
    }).session(session);

    if (!transaction) {
      throw new Error('No active transaction found for this book');
    }

  
    transaction.actualReturnDate = actualReturnDate ? new Date(actualReturnDate) : new Date();
    
    
    transaction.calculateFine();
    
    transaction.status = 'COMPLETED';
    transaction.remarks = remarks || transaction.remarks;
    transaction.transactionType = 'RETURN';

    await transaction.save({ session });

    
    book.status = 'AVAILABLE';
    await book.save({ session });

    
    if (transaction.fineCalculated > 0) {
      membership.fineAmount = (membership.fineAmount || 0) + transaction.fineCalculated;
      await membership.save({ session });
    }

    await session.commitTransaction();
    session.endSession();

    const populatedTransaction = await Transaction.findById(transaction._id)
      .populate('membership')
      .populate('book');

    res.json({
      success: true,
      message: 'Book returned successfully',
      transaction: populatedTransaction,
      fineAmount: transaction.fineCalculated
    });
  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};


exports.getOverdueReturns = async (req, res) => {
  try {
    const transactions = await Transaction.find({
      status: 'ACTIVE',
      returnDate: { $lt: new Date() }
    })
    .populate('membership')
    .populate('book');


    transactions.forEach(t => t.calculateFine());

    res.json({
      success: true,
      transactions
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};


exports.getMemberTransactions = async (req, res) => {
  try {
    const membership = await Membership.findOne({ membershipId: req.params.membershipId });
    if (!membership) {
      return res.status(404).json({
        success: false,
        message: 'Membership not found'
      });
    }

    const transactions = await Transaction.find({ membership: membership._id })
      .populate('book')
      .sort('-createdAt');

    res.json({
      success: true,
      transactions
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};


exports.checkAvailability = async (req, res) => {
  try {
    const book = await Book.findOne({ serialNo: req.params.serialNo });
    
    res.json({
      success: true,
      available: book ? book.status === 'AVAILABLE' : false
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};