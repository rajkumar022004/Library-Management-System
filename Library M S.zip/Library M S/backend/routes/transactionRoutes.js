const express = require('express');
const router = express.Router();
const {
  issueBook,
  returnBook,
  getOverdueReturns,
  getMemberTransactions,
  checkAvailability
} = require('../controllers/transactionController');
const { protect } = require('../middleware/authMiddleware');

router.use(protect);

router.post('/issue', issueBook);
router.post('/return', returnBook);
router.get('/overdue', getOverdueReturns);
router.get('/member/:membershipId', getMemberTransactions);
router.get('/check-availability/:serialNo', checkAvailability);

module.exports = router;